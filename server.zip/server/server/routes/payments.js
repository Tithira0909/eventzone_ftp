// server/routes/payments.js
import express from "express";
import crypto from "node:crypto";
import { pool } from "../db.js";

const router = express.Router();

/* ------------ ENV (accept token alias) ------------ */
const APP_ID        = (process.env.ONEPAY_APP_ID || "").trim();
const APP_TOKEN     = (process.env.ONEPAY_APP_TOKEN || process.env.ONEPAY_API_KEY || "").trim();
const HASH_SALT     = (process.env.ONEPAY_HASH_SALT || "").trim();
const FRONTEND_BASE =
  (process.env.FRONTEND_BASE || process.env.CORS_ORIGIN || "http://localhost:5173").trim();

/* ---------------- utilities ---------------- */
const to2dp = (n) => Number(n || 0).toFixed(2);
function toE164(phone) {
  const p = String(phone || "").replace(/[^\d+]/g, "");
  return p.startsWith("+") ? p : (p ? `+${p}` : "");
}
function splitName(full = "") {
  const parts = String(full).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return { first: "-", last: "" };
  if (parts.length === 1) return { first: parts[0], last: "" };
  return { first: parts.slice(0, -1).join(" "), last: parts.at(-1) };
}
// hash v1: app+ref+amount+currency+salt
const hashV1 = ({ appId, reference, amount2dp, currency, salt }) =>
  crypto.createHash("sha256").update(`${appId}${reference}${amount2dp}${currency}${salt}`).digest("hex");
// hash v2: app+ref+amount+salt  (some tenants use this)
const hashV2 = ({ appId, reference, amount2dp, salt }) =>
  crypto.createHash("sha256").update(`${appId}${reference}${amount2dp}${salt}`).digest("hex");

/* ---------------- OnePay helpers ---------------- */
async function opCreateItem(item) {
  const r = await fetch("https://api.onepay.lk/v3/item/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${APP_TOKEN}`,
    },
    body: JSON.stringify(item),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || data?.status !== 200) {
    const err = new Error(data?.message || `ONEPAY_ITEM_HTTP_${r.status}`);
    err.data = data;
    throw err;
  }
  return data.data.item_id;
}

async function postCheckout(payload) {
  const r = await fetch("https://api.onepay.lk/v3/checkout/link/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${APP_TOKEN}`, // required for many tenants
    },
    body: JSON.stringify(payload),
  });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok && data?.status === 200, status: r.status, data };
}

/* ---------------- routes ---------------- */
router.post("/onepay/link", async (req, res) => {
  if (!APP_ID || !APP_TOKEN || !HASH_SALT) {
    const missing = [
      !APP_ID && "ONEPAY_APP_ID",
      !APP_TOKEN && "ONEPAY_APP_TOKEN/ONEPAY_API_KEY",
      !HASH_SALT && "ONEPAY_HASH_SALT",
    ].filter(Boolean);
    return res.status(500).json({ ok: false, error: "ONEPAY_ENV_MISSING", missing });
  }

  const { orderId } = req.body || {};
  if (!orderId) return res.status(400).json({ ok: false, error: "MISSING_ORDER_ID" });

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [orders] = await conn.query(
      `SELECT o.id, o.currency, o.amount, o.status, o.customer_id,
              c.full_name, c.email, c.phone
         FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
        WHERE o.id = ?`,
      [orderId]
    );
    if (!orders.length) {
      await conn.rollback();
      return res.status(404).json({ ok: false, error: "ORDER_NOT_FOUND" });
    }
    const order = orders[0];
    if (String(order.status).toUpperCase() === "PAID") {
      await conn.rollback();
      return res.status(409).json({ ok: false, error: "ALREADY_PAID" });
    }

    const [rows] = await conn.query(
      `SELECT table_id AS tableCode, seat_no AS seatNo, category, price
         FROM order_items
        WHERE order_id = ?`,
      [orderId]
    );
    if (!rows.length) {
      await conn.rollback();
      return res.status(400).json({ ok: false, error: "NO_ITEMS" });
    }

    // Create OnePay items
    const onepayItemIds = [];
    for (const it of rows) {
      const seatNo = Number(it.seatNo);
      const price  = Number(it.price);
      const table  = String(it.tableCode || "").trim();
      if (!table || !Number.isFinite(seatNo) || !Number.isFinite(price)) {
        await conn.rollback();
        return res.status(400).json({ ok: false, error: "BAD_ITEM" });
      }
      const itemBody = {
        name: `${(it.category || "ticket").toUpperCase()} – ${table} Seat ${seatNo}`,
        description: `Event ticket for table ${table}, seat ${seatNo}`,
        price,
        currency: "LKR",
        image_url: "https://onepay.lk/static/img/ticket.png",
        metadata: { table, seat: String(seatNo), category: String(it.category || "") },
      };
      const id = await opCreateItem(itemBody);
      onepayItemIds.push(id);
    }

    // ---- Build payloads (unique reference, sanitized customer) ---------------
    const uniqueRef = `${order.id}-${Date.now()}`;       // keep ref unique
    const currency  = (order.currency || "LKR").trim().toUpperCase();
    const amount2dp = to2dp(order.amount);
    const { first, last } = splitName(order.full_name || "-");

    let phone = toE164(order.phone || "");
    const digits = phone.replace(/\D/g, "").length;
    if (!(phone.startsWith("+") && digits >= 10)) phone = "";

    const base = {
      app_id: APP_ID,
      currency,
      amount: amount2dp,
      reference: uniqueRef,
      transaction_redirect_url: `${FRONTEND_BASE}/payment/return?ref=${encodeURIComponent(order.id)}`,
      additionalData: `order=${order.id}`,
    };
    if (first) base.customer_first_name = first;
    if (last)  base.customer_last_name  = last;
    if (order.email) base.customer_email = String(order.email).trim();
    if (phone)       base.customer_phone_number = phone;

    const itemsBlock = { items: onepayItemIds.map(id => ({ item_id: id, quantity: 1 })) };

    // Try: hash V1 + items → V1 w/o items → hash V2 + items → V2 w/o items
    const attempts = [
      { payload: { ...base, hash: hashV1({ appId: APP_ID, reference: uniqueRef, amount2dp, currency, salt: HASH_SALT }), ...itemsBlock }, label: "v1+items" },
      { payload: { ...base, hash: hashV1({ appId: APP_ID, reference: uniqueRef, amount2dp, currency, salt: HASH_SALT }) }, label: "v1" },
      { payload: { ...base, hash: hashV2({ appId: APP_ID, reference: uniqueRef, amount2dp, salt: HASH_SALT }), ...itemsBlock }, label: "v2+items" },
      { payload: { ...base, hash: hashV2({ appId: APP_ID, reference: uniqueRef, amount2dp, salt: HASH_SALT }) }, label: "v2" },
    ];

    // small debug snapshot
    console.log("[ONEPAY_PAYLOAD_BASE]", {
      app_id: base.app_id,
      ref: base.reference,
      amount: base.amount,
      currency: base.currency,
      hasPhone: !!base.customer_phone_number,
      items: onepayItemIds.length
    });

    let response, used;
    for (const a of attempts) {
      const r = await postCheckout(a.payload);
      if (r.ok) { response = r; used = a.label; break; }
      if (r.status !== 400) { response = r; used = a.label; break; } // non-400 → stop
    }

    if (!response?.ok) {
      console.error("[ONEPAY_LINK_ERROR]", { used, status: response?.status, body: response?.data });
      const err = new Error(response?.data?.message || `ONEPAY_LINK_HTTP_${response?.status || "?"}`);
      err.data = response?.data;
      throw err;
    }

    const redirectUrl = response.data?.data?.gateway?.redirect_url;

    await conn.query(`UPDATE orders SET status = ? WHERE id = ?`, ["PENDING_PAYMENT", orderId]);
    await conn.commit();
    return res.json({ ok: true, checkoutUrl: redirectUrl });
  } catch (e) {
    try { await conn.rollback(); } catch {}
    console.error("[ONEPAY_LINK_ERROR]", e?.data || e);
    return res.status(500).json({ ok: false, error: e?.data?.message || e.message || "ONEPAY_LINK_FAILED" });
  } finally {
    conn.release();
  }
});

export default router;

// server/db.js (CommonJS)
require("dotenv").config();
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "eventuser",
  password: process.env.DB_PASSWORD || "event12345",
  database: process.env.DB_NAME || "eventzone",
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_POOL || 30),
  queueLimit: 0,
  namedPlaceholders: true, // enables `:name` style placeholders
  // Uncomment if your DB needs SSL:
  // ssl: process.env.DB_SSL === "true" ? { rejectUnauthorized: true } : undefined,
});

module.exports = { pool };

// server/routes/locks.js
import express from "express";
import { pool } from "../db.js";

export const router = express.Router();
const EVENT_ID = "default";

/** GET /api/locks -> { ok: true, locks: [{tableId, seatNo}] } */
router.get("/locks", async (_req, res) => {
  try {
    await pool.execute("DELETE FROM seat_locks WHERE expires_at < NOW()");
    const [rows] = await pool.execute(
      "SELECT table_id AS tableId, seat_no AS seatNo FROM seat_locks WHERE event_id=? AND expires_at > NOW()",
      [EVENT_ID]
    );
    res.json({ ok: true, locks: rows });
  } catch (e) {
    console.error("[locks] GET", e);
    res.status(500).json({ ok: false, error: "locks_fetch_failed" });
  }
});

/** POST /api/locks/hold */
router.post("/locks/hold", async (req, res) => {
  const seats = Array.isArray(req.body?.seats) ? req.body.seats : [];
  const ttlSec = Number(req.body?.ttlSec ?? 600);
  const clientHoldId = req.body?.holdId;

  if (!seats.length) return res.status(422).json({ ok:false, message:"seats[] required" });
  if (!Number.isFinite(ttlSec) || ttlSec <= 0) return res.status(422).json({ ok:false, message:"ttlSec invalid" });

  const holdId = clientHoldId || `H${Date.now().toString(36)}${Math.random().toString(36).slice(2,8)}`.toUpperCase();

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    await conn.execute("DELETE FROM seat_locks WHERE expires_at < NOW()");

    const orClause = seats.map(() => "(event_id=? AND table_id=? AND seat_no=?)").join(" OR ");
    const orParams = seats.flatMap(s => [EVENT_ID, s.tableId, Number(s.seatNo)]);

    const [conflicts] = await conn.execute(
      `SELECT table_id AS tableId, seat_no AS seatNo
         FROM seat_locks
        WHERE expires_at > NOW() AND (${orClause})`,
      orParams
    );
    if (conflicts.length) {
      await conn.rollback();
      return res.status(409).json({ ok:false, message:"Some seats already held", conflicts });
    }

    const [rows] = await conn.query("SELECT NOW() AS now");
    const now = new Date(rows[0].now);
    const expiresAt = new Date(now.getTime() + ttlSec*1000);

    for (const s of seats) {
      await conn.execute(
        `INSERT INTO seat_locks (event_id, table_id, seat_no, hold_id, expires_at)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE hold_id=VALUES(hold_id), expires_at=VALUES(expires_at)`,
        [EVENT_ID, s.tableId, Number(s.seatNo), holdId, expiresAt]
      );
    }

    await conn.commit();
    res.json({ ok:true, holdId, seats, expiresAt: Math.floor(expiresAt.getTime()/1000) });
  } catch (e) {
    await conn.rollback();
    console.error("[locks] POST", e);
    res.status(500).json({ ok:false, error:"hold_failed" });
  } finally {
    conn.release();
  }
});

const express = require("express");
const router = express.Router();

// NOTE: You must export pool from index.js for this to work, 
// OR the pool object must be passed into this router.
// Assuming your setup passes the pool object or you have exported it from db.js
// Since you provided 'const { pool } = require("../db");'
// I will assume you fix the import path OR pass the pool object.
// For now, I'll keep the original import to avoid creating circular dependencies.
const { pool } = require("../db"); 

/* ---------- helpers ---------- */
function isVip(tableId) {
  const letter = String(tableId || "").trim().charAt(0).toUpperCase();
  return ["A", "B", "C", "D", "E"].includes(letter);
}
function rand(n = 7) {
  return Math.random().toString(36).slice(2, 2 + n).toUpperCase();
}

/* =========================================================================
   LIST ORDERS
   ========================================================================= */
router.get("/orders", async (_req, res) => {
  const conn = await pool.getConnection();
  try {
    const [orderCols] = await conn.query("SHOW COLUMNS FROM orders");
    const has = (name) => orderCols.some((c) => c.Field === name);

    const idStrCol =
      (has("order_id") && "o.order_id") ||
      (has("order_ref") && "o.order_ref") ||
      "NULL";

    const amountCol =
      (has("amount") && "o.amount") ||
      (has("net_amount") && "o.net_amount") ||
      (has("gross_amount") && "o.gross_amount") ||
      "0";
    const currencyCol = has("currency") ? "o.currency" : "'LKR'";
    const statusCol = has("status") ? "o.status" : "'created'";
    const descCol = has("description") ? "o.description" : "''";
    const createdAtCol = has("created_at") ? "o.created_at" : "NOW()";
    const checkedAtCol = has("checked_in_at") ? "o.checked_in_at" : "NULL";

    const custSelect =
      "TRIM(CONCAT(IFNULL(o.customer_first_name,''),' ',IFNULL(o.customer_last_name,''))) AS customer_name, " +
      (has("customer_email") ? "o.customer_email" : "NULL") + " AS customer_email, " +
      (has("customer_phone") ? "o.customer_phone" : "NULL") + " AS customer_phone";

    const sqlOrders = `
      SELECT o.id,
             ${idStrCol}     AS order_id,
             ${amountCol}    AS amount,
             ${currencyCol}  AS currency,
             ${statusCol}    AS status,
             ${descCol}      AS description,
             ${createdAtCol} AS ts,
             ${checkedAtCol} AS checked_in_at,
             ${custSelect}
        FROM orders o
        ORDER BY o.id DESC`;

    const [orders] = await conn.query(sqlOrders);

    const [[hasItemsTable]] = await conn.query("SHOW TABLES LIKE 'order_items'");
    let items = [];
    if (hasItemsTable) {
      const [itemCols] = await conn.query("SHOW COLUMNS FROM order_items");
      const ih = (n) => itemCols.some((c) => c.Field === n);
      const priceExpr = ih("price_cents")
        ? "oi.price_cents/100"
        : ih("price")
        ? "oi.price"
        : "0";
      const tableExpr = ih("table_id") ? "oi.table_id" : "NULL";
      const seatExpr = ih("seat_no")
        ? "oi.seat_no"
        : ih("seat")
        ? "oi.seat"
        : "NULL";
      const catExpr = ih("category")
        ? "oi.category"
        : ih("table_id")
        ? "CASE WHEN UPPER(LEFT(oi.table_id,1)) IN ('A','B','C','D','E') THEN 'vip' ELSE 'general' END"
        : "'general'";

      const [rows] = await conn.query(
        `SELECT oi.order_id,
                 ${tableExpr} AS table_id,
                 ${seatExpr}  AS seat_no,
                 ${catExpr}   AS category,
                 ${priceExpr} AS price
            FROM order_items oi`
      );
      items = rows;
    }

    const byOrderPk = new Map();
    for (const o of orders) {
      byOrderPk.set(o.id, {
        orderId: o.order_id || `#${o.id}`,
        amount: Number(o.amount || 0),
        currency: o.currency || "LKR",
        status: o.status || "created",
        description: o.description || "",
        ts: o.ts,
        checkedInAt: o.checked_in_at || null,
        items: [],
      });
    }

    for (const it of items) {
      const row = byOrderPk.get(it.order_id);
      if (row) {
        row.items.push({
          id: `${it.table_id}-${it.seat_no}`,
          tableId: it.table_id,
          seatNo: it.seat_no,
          category: it.category,
          price: Number(it.price || 0),
        });
      }
    }

    res.json({ ok: true, orders: Array.from(byOrderPk.values()) });
  } catch (e) {
    console.error("[ADMIN][orders] Error:", e);
    res.status(500).json({
      ok: false,
      error: "ORDERS_FETCH_FAILED",
      sqlMessage: e?.sqlMessage,
    });
  } finally {
    conn.release();
  }
});

/* =========================================================================
   CHECK-IN (uses safe ENUM value)
   ========================================================================= */
router.post("/checkin", async (req, res) => {
  const { orderId } = req.body || {};
  if (!orderId) return res.status(400).json({ ok: false, error: "NO_ORDER_ID" });

  const conn = await pool.getConnection();
  try {
    const [orderCols] = await conn.query("SHOW COLUMNS FROM orders");
    const has = (n) => orderCols.some((c) => c.Field === n);
    const idCol = has("order_id")
      ? "order_id"
      : has("order_ref")
      ? "order_ref"
      : null;
    if (!idCol)
      return res.status(400).json({ ok: false, error: "NO_ORDER_ID_COLUMN" });

    let sql = `UPDATE orders SET status = 'checked_in'`;
    if (has("checked_in_at")) sql += `, checked_in_at = NOW()`;
    if (has("updated_at")) sql += `, updated_at = NOW()`;
    sql += ` WHERE ${idCol} = ?`;

    const [r] = await conn.query(sql, [String(orderId)]);
    res.json({ ok: true, updated: r.affectedRows });
  } catch (e) {
    console.error("[ADMIN][checkin] Error:", e);
    res.status(500).json({
      ok: false,
      error: "CHECKIN_FAILED",
      sqlMessage: e?.sqlMessage,
    });
  } finally {
    conn.release();
  }
});

/* =========================================================================
   CREATE Ticket-Book / PickMe orders
   ========================================================================= */
router.post("/ticket-book", async (req, res) => {
  const { tableId, seats, orderId: customOrderId, source = "ticket_book" } =
    req.body || {};

  const tId = String(tableId || "").trim();
  const seatList = Array.isArray(seats)
    ? seats.map(Number).filter((n) => n >= 1 && n <= 10)
    : [];
  if (!tId || seatList.length === 0) {
    return res.status(400).json({ ok: false, error: "BAD_ITEM" });
  }

  const category = isVip(tId) ? "vip" : "general";
  const unit = category === "vip" ? 7500 : 5000;
  const items = seatList.map((n) => ({
    tableId: tId,
    seatNo: n,
    category,
    price: unit,
  }));
  const amount = items.reduce((s, it) => s + (it.price || 0), 0);

  const src = String(source).toLowerCase() === "pickme" ? "pickme" : "ticketbook";
  const statusLabel = src; // ENUM-safe lowercase
  const descLabel = src === "pickme" ? "PickMe" : "Ticket Book";
  const payMethod = src === "pickme" ? "PICKME" : "TICKET_BOOK";
  const idPrefix = src === "pickme" ? "PME" : "TBK";

  const outOrderId = customOrderId || `${idPrefix}-${tId}-${rand(4)}`;
  const orderKey = `OK_${rand(12)}`;

  const conn2 = await pool.getConnection();
  try {
    await conn2.beginTransaction();

    const [orderCols] = await conn2.query("SHOW COLUMNS FROM orders");
    const has = (n) => orderCols.some((c) => c.Field === n);
    const cols = [];
    const vals = [];
    const qms = [];

    if (has("order_id")) { cols.push("order_id"); vals.push(outOrderId); qms.push("?"); }
    if (has("order_ref") && !has("order_id")) { cols.push("order_ref"); vals.push(outOrderId); qms.push("?"); }
    if (has("order_key")) { cols.push("order_key"); vals.push(orderKey); qms.push("?"); }
    if (has("currency")) { cols.push("currency"); vals.push("LKR"); qms.push("?"); }
    if (has("amount")) { cols.push("amount"); vals.push(amount); qms.push("?"); }
    if (has("pay_method")) { cols.push("pay_method"); vals.push(payMethod); qms.push("?"); }
    if (has("status")) { cols.push("status"); vals.push(statusLabel); qms.push("?"); }
    if (has("description")) { cols.push("description"); vals.push(descLabel); qms.push("?"); }

    if (cols.length === 0)
      return res.status(400).json({
        ok: false,
        error: "ORDERS_TABLE_MISSING_WRITABLE_COLUMNS",
      });

    const [ins] = await conn2.query(
      `INSERT INTO orders (${cols.join(",")}) VALUES (${qms.join(",")})`,
      vals
    );
    const newOrderPk = ins.insertId;

    const [[hasItemsTable]] = await conn2.query("SHOW TABLES LIKE 'order_items'");
    if (hasItemsTable) {
      const [itemCols] = await conn2.query("SHOW COLUMNS FROM order_items");
      const ih = (n) => itemCols.some((c) => c.Field === n);
      const useCents = ih("price_cents");

      for (const it of items) {
        if (useCents) {
          await conn2.query(
            `INSERT INTO order_items (order_id, table_id, seat_no, category, price_cents)
             VALUES (?, ?, ?, ?, ?)`,
            [newOrderPk, it.tableId, it.seatNo, it.category, Math.round(it.price * 100)]
          );
        } else {
          if (ih("category")) {
            await conn2.query(
              `INSERT INTO order_items (order_id, table_id, seat_no, category, price)
               VALUES (?, ?, ?, ?, ?)`,
              [newOrderPk, it.tableId, it.seatNo, it.category, it.price]
            );
          } else {
            await conn2.query(
              `INSERT INTO order_items (order_id, table_id, seat_no, price)
               VALUES (?, ?, ?, ?)`,
              [newOrderPk, it.tableId, it.seatNo, it.price]
            );
          }
        }
      }
    }

    await conn2.commit();
    res.json({ ok: true, orderId: outOrderId, id: newOrderPk });
  } catch (e) {
    await conn2.rollback();
    console.error("[ADMIN][ticket-book] Error:", e);
    res.status(500).json({
      ok: false,
      error: "TICKET_BOOK_SAVE_FAILED",
      sqlMessage: e?.sqlMessage,
    });
  } finally {
    conn2.release();
  }
});

module.exports = router;
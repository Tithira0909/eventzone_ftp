// server/routes/onepay.js
import { Router } from "express";
import crypto from "crypto";

const router = Router();

/**
 * POST /api/onepay/prepare
 * Body: { amount: "7070.00", orderReference: "ORD123...", currency?: "LKR" }
 * Returns: { hashToken: string, mode: "PLAIN" | "HMAC" }
 */
router.post("/prepare", (req, res) => {
  const appid = process.env.ONEPAY_APP_ID;
  const hashSalt = process.env.ONEPAY_HASH_SALT; // from portal ("Hash Salt")
  const signMode = (process.env.ONEPAY_SIGN_MODE || "PLAIN").toUpperCase(); // PLAIN | HMAC

  const { amount, orderReference, currency = "LKR" } = req.body || {};
  if (!appid || !hashSalt) {
    return res.status(500).json({ ok: false, error: "SERVER_MISCONFIGURED" });
  }
  if (!amount || !orderReference) {
    return res.status(400).json({ ok: false, error: "MISSING_FIELDS" });
  }

  let hashToken;
  if (signMode === "HMAC") {
    // ⚠️ Confirm the exact string-to-sign with OnePay.
    // This is a *typical* pattern used by gateways:
    const toSign = `${appid}|${amount}|${currency}|${orderReference}`;
    hashToken = crypto.createHmac("sha256", hashSalt).update(toSign).digest("hex");
  } else {
    // PLAIN: just pass the salt as 'hashToken'
    hashToken = hashSalt;
  }

  res.json({ ok: true, hashToken, mode: signMode });
});

export default router;

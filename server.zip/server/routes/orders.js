// server/routes/orders.js
import express from "express";
import crypto from "crypto";
import { pool } from "../db.js"; // <- the mysql2/promise pool

export const router = express.Router();

/**
 * POST /api/orders/confirm
 *
 * Body:
 * {
 *   orderRef: string,
 *   holdId?: string,
 *   txId?: string,
 *   currency?: "LKR",
 *   amounts?: { gross: number, fee: number, net: number },
 *   customer: { firstName, lastName, email, phone },
 *   items: [
 *     // for seats:
 *     { type:"seat", tableId:"A-3", seatNo:1, qty:1, unitPrice:7000 },
 *     // for vip table bundle:
 *     { type:"vipTable", tableId:"A-1", qty:1, unitPrice:70000 }
 *   ],
 *   rawPayment?: any   // (optional) store in `payments.raw_payload`
 * }
 */
router.post("/confirm", async (req, res) => {
  const {
    orderRef,
    holdId = null,
    txId = "E9KU1190A12A2FFC604C5",
    currency = "LKR",
    customer = {},
    items = [],
    amounts = {},
    rawPayment = null,
  } = req.body || {};

  // ---- basic validation
  if (!orderRef) return res.status(400).json({ ok: false, message: "orderRef required" });
  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ ok: false, message: "items[] required" });
  }

  // ---- (re)compute totals safely server-side (trust but verify)
  const calc = items.reduce(
    (acc, it) => {
      const qty = Number(it.qty || 0);
      const unit = Number(it.unitPrice || 0);
      const amt = qty * unit;
      acc.gross += amt;
      return acc;
    },
    { gross: 0 }
  );

  // use client-provided fee/net if present, otherwise compute fee=1%, net=gross+fee
  const gross = Number(amounts?.gross ?? calc.gross);
  const fee   = Number(amounts?.fee   ?? Math.round(gross * 0.01 * 100) / 100);
  const net   = Number(amounts?.net   ?? gross + fee);

  let conn;
  try {
    conn = await pool.getConnection();
    await conn.beginTransaction();

    // ---- idempotency: if this order_ref already exists, return it
    const [existingRows] = await conn.execute(
      "SELECT id FROM orders WHERE order_ref=:orderRef LIMIT 1",
      { orderRef }
    );
    if (existingRows.length) {
      const orderId = existingRows[0].id;

      // fetch a compact view to return
      const [ord] = await conn.query(
        `SELECT o.*, 
                (SELECT JSON_ARRAYAGG(JSON_OBJECT(
                   'id', oi.id, 'type', oi.item_type, 'tableId', oi.table_id, 'seatNo', oi.seat_no,
                   'qty', oi.qty, 'unitPrice', oi.unit_price, 'amount', oi.amount
                 )) FROM order_items oi WHERE oi.order_id=o.id) AS items
         FROM orders o
         WHERE o.id=?`, [orderId]
      );
      await conn.commit();
      return res.json({ ok: true, idempotent: true, orderId, order: ord[0] });
    }

    // ---- if you use seat_locks, ensure this hold is valid & lock the seats
    if (holdId) {
      // optional: validate rows for that hold (and lock them)
      await conn.execute("DELETE FROM seat_locks WHERE expires_at < NOW()");
      // not fatal if there are no locks; you can enforce it if you want:
      // const [lockRows] = await conn.execute(
      //   "SELECT * FROM seat_locks WHERE hold_id=:holdId FOR UPDATE", { holdId }
      // );
      // if (lockRows.length === 0) throw new Error("hold_not_found");
    }

    // ---- insert into orders
    const [orderResult] = await conn.execute(
      `INSERT INTO orders
       (order_ref, hold_id, customer_first_name, customer_last_name, customer_email, customer_phone,
        currency, gross_amount, fee_amount, net_amount, status)
       VALUES (:orderRef, :holdId, :firstName, :lastName, :email, :phone,
               :currency, :gross, :fee, :net, 'paid')`,
      {
        orderRef,
        holdId,
        firstName: String(customer.firstName || ""),
        lastName:  String(customer.lastName || ""),
        email:     String(customer.email || ""),
        phone:     String(customer.phone || ""),
        currency,
        gross,
        fee,
        net,
      }
    );
    const orderId = orderResult.insertId;

    // ---- insert order_items
    for (const it of items) {
      const type = it.type === "vipTable" ? "vipTable" : "seat";
      const qty  = Number(it.qty || 0);
      const unit = Number(it.unitPrice || 0);
      const amt  = qty * unit;

      await conn.execute(
        `INSERT INTO order_items
         (order_id, item_type, table_id, seat_no, qty, unit_price, amount)
         VALUES (:orderId, :type, :tableId, :seatNo, :qty, :unitPrice, :amount)`,
        {
          orderId,
          type,
          tableId: it.tableId ?? null,
          seatNo:  it.seatNo ?? null,
          qty,
          unitPrice: unit,
          amount: amt,
        }
      );

      // ---- create tickets per seat (vipTable doesn't create individual seats here)
      if (type === "seat" && qty > 0) {
        // If you allow qty>1 for seats, repeat seat_no accordingly; here we assume qty=1 per seat row
        const qrCode = `T-${crypto.randomBytes(8).toString("hex").toUpperCase()}`; // store string only
        await conn.execute(
          `INSERT INTO tickets (order_id, table_id, seat_no, qr_code, status)
           VALUES (:orderId, :tableId, :seatNo, :qrCode, 'valid')`,
          { orderId, tableId: it.tableId ?? null, seatNo: it.seatNo ?? null, qrCode }
        );
      }
    }

    // ---- insert payment record
    await conn.execute(
      `INSERT INTO payments (order_id, provider, tx_id, amount, currency, status, raw_payload)
       VALUES (:orderId, 'onepay', :txId, :amount, :currency, 'captured', CAST(:raw AS JSON))`,
      {
        orderId,
        txId,
        amount: net,
        currency,
        raw: JSON.stringify(rawPayment ?? { ok: true, source: "fake-gateway" }),
      }
    );

    // ---- release seat_locks for this hold (optional but recommended)
    if (holdId) {
      await conn.execute(
        "DELETE FROM seat_locks WHERE hold_id=:holdId",
        { holdId }
      );
    }

    await conn.commit();

    return res.json({
      ok: true,
      orderId,
      orderRef,
      txId,
      totals: { gross, fee, net, currency },
    });
  } catch (e) {
    if (conn) await conn.rollback();
    console.error("[orders/confirm] error:", e);
    // duplicate order_ref -> idempotency race; return a friendly response
    if (e?.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ ok: false, message: "order_ref already exists" });
    }
    return res.status(500).json({ ok: false, message: "server_error" });
  } finally {
    if (conn) conn.release();
  }
});

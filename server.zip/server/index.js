"use strict";

const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const QRCode = require("qrcode");
const { MailerSend, EmailParams, Sender, Recipient, Attachment } = require("mailersend");
const crypto = require("crypto");
const mysql = require("mysql2/promise");
const axios = require("axios");

dotenv.config();

/* ───────── ENV ───────── */
const {
  PORT = 5055,
  FRONTEND_ORIGIN = "http://localhost:5173",

  MYSQL_HOST,
  MYSQL_PORT = "3306",
  MYSQL_USER,
  MYSQL_PASSWORD,
  MYSQL_DB,

  MAILERSEND_API_KEY,
  MAIL_FROM_EMAIL,
  MAIL_FROM_NAME,

  PUBLIC_ORDER_BASE = "https://eventz.lk/order",
  QR_SIGNING_SECRET = "",

  ATTACH_TICKET_JSON = "0",

  // --- ONEPAY KEYS ---
  ONEPAY_APP_ID,
  ONEPAY_HASH_SALT,
  ONEPAY_APP_TOKEN,
  ONEPAY_API_URL = "https://api.onepay.lk/v3/checkout/link/",
  ONEPAY_STATUS_API_URL = "https://api.onepay.lk/v3/transaction/status/",
  MY_WEBSITE_REDIRECT_URL = "http://localhost:5173/payment-complete.html", // CHECK THIS FILENAME!
} = process.env;

/* ───────── Admin Router Safety Load ───────── */
let adminRouter;
try {
  adminRouter = require("./routes/admin.js");
  console.log("[Admin Router] Loaded successfully.");
} catch (e) {
  console.warn(`[Admin Router] WARNING: Could not load routes/admin.js. Admin API disabled.`);
  console.warn(`[Admin Router] Error: ${e.message}`);
  adminRouter = express.Router();
}

/* ───────── App ───────── */
const app = express();
app.use(express.json({ limit: "256kb" }));
app.use(cors({ origin: FRONTEND_ORIGIN }));
app.use("/api/admin", adminRouter);

/* ───────── MySQL Pool ───────── */
if (!MYSQL_HOST || !MYSQL_USER || !MYSQL_DB) {
  console.error("[MySQL] env missing (MYSQL_HOST, MYSQL_USER, MYSQL_DB are required).");
  process.exit(1);
}
// --- Check for OnePay ENV Vars ---
if (!ONEPAY_APP_ID || !ONEPAY_HASH_SALT || !ONEPAY_APP_TOKEN) {
  console.error("[OnePay] env missing (ONEPAY_APP_ID, ONEPAY_HASH_SALT, ONEPAY_APP_TOKEN are required).");
  process.exit(1);
}
const pool = mysql.createPool({
  host: MYSQL_HOST,
  port: Number(MYSQL_PORT),
  user: MYSQL_USER,
  password: MYSQL_PASSWORD,
  database: MYSQL_DB,
  connectionLimit: 10,
  namedPlaceholders: true,
});
pool
  .query("SELECT 1")
  .then(() => console.log("[MySQL] connected"))
  .catch((e) => {
    console.error("[MySQL] connection failed:", e.message);
    process.exit(1);
  });

/* ───────── MailerSend ───────── */
const mailerSend = new MailerSend({ apiKey: MAILERSEND_API_KEY || "" });
const mailEnabled = Boolean(MAILERSEND_API_KEY && MAIL_FROM_EMAIL && MAIL_FROM_NAME);
console.log(
  mailEnabled
    ? "[MailerSend] API client is ready."
    : "[MailerSend] MAILERSEND_API_KEY, MAIL_FROM_EMAIL, or MAIL_FROM_NAME is missing. Emails will be skipped."
);

/* ───────── Helpers ───────── */
const isEmail = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(e || "").trim());

function ticketEmailHtml({ firstName, orderId, orderRef, total, currency }) {
  // (Your existing ticketEmailHtml function... no changes needed)
  return `
  <div style="font-family:Inter,system-ui,Segoe UI,Arial,sans-serif;background:#0b1120;color:#e5fff9;padding:24px">
    <div style="max-width:640px;margin:0 auto;border:1px solid rgba(255,255,255,0.08);border-radius:16px;background:#0f172a;padding:24px">
      <h2 style="margin:0 0 12px 0;color:#5eead4">Your Ticket</h2>
      <p style="color:#c3f3ea">Hi ${firstName || "there"}, your payment was <b>successful</b>. Your QR ticket is <b>attached</b> to this email as an image.</p>
      <div style="margin:16px 0;padding:16px;border:1px solid rgba(255,255,255,0.06);border-radius:12px;background:rgba(2,6,23,0.35)">
        <div style="margin-bottom:10px"><div style="opacity:.7;font-size:12px">Order ID</div><div style="font-weight:600">${orderId}</div></div>
        <div style="margin-bottom:10px"><div style="opacity:.7;font-size:12px">Reference</div><div style="font-weight:600">${orderRef}</div></div>
        <div><div style="opacity:.7;font-size:12px">Total</div><div style="font-weight:700;color:#facc15">${total} ${currency}</div></div>
      </div>
      <p style="margin-top:16px;color:#9bd7cd;font-size:13px">Please download or show the <b>attached QR image</b> at the gate. If you have questions, reply to this email.</p>
      <div style="margin-top:24px;border-top:1px solid rgba(255,255,255,0.06);padding-top:12px;opacity:.7;font-size:12px">© ${new Date().getFullYear()} Eventz One. All rights reserved.</div>
    </div>
  </div>`;
}

/* ───────── QR helpers ───────── */
const b64url = (buf) =>
  Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");

function signFields(fields) {
  const secret = String(QR_SIGNING_SECRET || "");
  if (!secret) { console.warn("QR_SIGNING_SECRET is not set in .env! QR signature will be weak."); }
  const s = [fields.orderId, fields.orderRef, fields.txId || "", String(fields.iat || 0)].join("|");
  return b64url(crypto.createHmac("sha256", secret).update(s).digest());
}

function buildQrJson({ orderId, orderRef, txId, seats }) {
  const payload = {
    v: 1, typ: "eventz_ticket", orderId, orderRef, txId: txId || "", seats, iat: Math.floor(Date.now() / 1000),
  };
  payload.sig = signFields(payload);
  return JSON.stringify(payload);
}

function verifyQrJson(jsonText) {
  let data;
  try { data = JSON.parse(jsonText); } catch { return { ok: false, reason: "bad_json" }; }
  if (!data || data.typ !== "eventz_ticket" || data.v !== 1) return { ok: false, reason: "bad_type" };
  const expected = signFields(data);
  if (expected !== data.sig) return { ok: false, reason: "bad_sig" };
  return { ok: true, data };
}

/* ───────── Attachment sanity helpers ───────── */
function toBase64(buf) { return Buffer.from(buf).toString("base64"); }
function assertPng(buf) {
  const m = buf.slice(0, 8);
  if (!(m[0] === 0x89 && m[1] === 0x50 && m[2] === 0x4e && m[3] === 0x47)) {
    throw new Error("QR buffer is not a PNG (bad magic).");
  }
}
function assertJsonText(buf) { JSON.parse(buf.toString("utf8")); }

/* ───────── ADDED: PAYMENT HASH HELPER ───────── */
function generatePaymentHash(appId, currency, amountString, salt) {
  const message = appId + currency + amountString + salt;
  const hash = crypto.createHash('sha256').update(message).digest('hex');
  return hash;
}

/* ───────── Health ───────── */
app.get("/api/health", async (_req, res) => {
  try {
    const [rows] = await pool.query("SELECT COUNT(*) AS c FROM seat_locks WHERE expires_at > NOW()");
    const activeLocks = rows?.[0]?.c ?? 0;
    return res.status(200).json({ ok: true, db: true, mail: mailEnabled, activeLocks });
  } catch {
    return res.status(200).json({ ok: true, db: true, mail: mailEnabled });
  }
});

/* ==================================================================== */
/* 1) CREATE ORDER & CHECKOUT (NEW SECURE ENDPOINT) */
/* ==================================================================== */
app.post("/api/orders/create-checkout", async (req, res) => {
  const {
    orderReference,
    holdId = null,
    currency = "LKR",
    customer = {},
    items = [],
  } = req.body || {};

  console.log(`\n--- [Checkout Start] Ref: ${orderReference} ---`);

  const conn = await pool.getConnection();
  console.log("[Checkout] DB connection obtained.");

  try {
    // ---- 1. Validation ----
    console.log("[Checkout] Validating input...");
    if (!orderReference) return res.status(400).json({ ok: false, message: "orderReference required" });
    if (!customer?.email || !isEmail(customer.email)) {
      return res.status(400).json({ ok: false, message: "valid customer.email required" });
    }
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ ok: false, message: "items array is required" });
    }
    console.log("[Checkout] Validation passed.");

    // ---- 2. Check for Idempotency ----
    console.log("[Checkout] Checking idempotency...");
    const [existing] = await pool.execute(
      "SELECT id, status FROM orders WHERE order_ref=:ref LIMIT 1",
      { ref: orderReference }
    );
    if (existing.length && existing[0].status !== 'pending') {
       console.warn(`[Checkout] Order ${orderReference} already processed (status: ${existing[0].status}).`);
       return res.status(409).json({ ok: false, message: "Order already processed." });
    }
    console.log("[Checkout] Idempotency check passed.");

    // ---- 3. Calculate Totals ----
    console.log("[Checkout] Calculating totals...");
    const subtotal = (items || []).reduce((sum, it) => sum + (Number(it?.qty ?? 1) * Number(it?.unitPrice ?? it?.price ?? 0)), 0);
    const fee = Math.round(subtotal * 0.01 * 100) / 100;
    const total = Math.round((subtotal + fee) * 100) / 100;
    console.log(`[Checkout] Total calculated: ${total}`);

    // ---- 4. Create PENDING Order in DB ----
    console.log("[Checkout] Starting DB transaction...");
    await conn.beginTransaction();

    // Upsert the order
    const [ordRes] = await conn.execute(
      `INSERT INTO orders
       (order_ref, hold_id, customer_first_name, customer_last_name, customer_email, customer_phone,
        currency, gross_amount, fee_amount, net_amount, status)
       VALUES (:orderRef, :holdId, :firstName, :lastName, :email, :phone,
               :currency, :gross, :fee, :net, 'pending')
       ON DUPLICATE KEY UPDATE
        hold_id = VALUES(hold_id), customer_first_name = VALUES(customer_first_name), customer_last_name = VALUES(customer_last_name),
        customer_email = VALUES(customer_email), customer_phone = VALUES(customer_phone), gross_amount = VALUES(gross_amount),
        status = 'pending'`,
      {
        orderRef: orderReference, holdId,
        firstName: String(customer.firstName || ""), lastName: String(customer.lastName || ""),
        email: String(customer.email || ""), phone: String(customer.phone || ""),
        currency, gross: total, fee, net: subtotal,
      }
    );
    console.log(`[Checkout] Pending order ${orderReference} saved/updated.`);

    // Get the *actual* order ID, whether new or existing
    const [[{ id: finalOrderId }]] = await conn.execute("SELECT id FROM orders WHERE order_ref = :ref", { ref: orderReference });

    // Clear old items first in case this is a re-try
    await conn.execute("DELETE FROM order_items WHERE order_id = :orderId", { orderId: finalOrderId });

    // Insert new items
    for (const it of items) {
       await conn.execute(
        `INSERT INTO order_items (order_id, item_type, table_id, seat_no, qty, unit_price, amount)
         VALUES (:orderId, :type, :tableId, :seatNo, :qty, :unit, :amt)`,
        {
          orderId: finalOrderId, type: it.type === "vipTable" ? "vipTable" : "seat",
          tableId: it.tableId ?? null, seatNo: it.seatNo ?? null,
          qty: Number(it.qty ?? 1), unit: Number(it.unitPrice ?? it.price ?? 0),
          amt: Number(it.qty ?? 1) * Number(it.unitPrice ?? it.price ?? 0),
        }
      );
    }
    console.log(`[Checkout] Pending items for ${orderReference} saved.`);

    await conn.commit();
    console.log("[Checkout] DB transaction committed.");

    // 5. Generate OnePay Link
    console.log("[Checkout] Generating OnePay hash...");
    const amountStringForHash = total.toFixed(2);
    const hash = generatePaymentHash( ONEPAY_APP_ID, currency, amountStringForHash, ONEPAY_HASH_SALT );
    console.log("[Checkout] OnePay hash generated.");

    const payload = {
      currency: currency, app_id: ONEPAY_APP_ID, hash: hash, amount: total,
      reference: orderReference, customer_first_name: String(customer.firstName || ""),
      customer_last_name: String(customer.lastName || ""), customer_phone_number: String(customer.phone || ""),
      customer_email: String(customer.email || ""), transaction_redirect_url: MY_WEBSITE_REDIRECT_URL,
      additionalData: `Order ${orderReference}`
    };

    console.log("[Checkout] Calling OnePay API...");
    const onePayResponse = await axios.post(ONEPAY_API_URL, payload, {
      headers: { 'Authorization': ONEPAY_APP_TOKEN, 'Content-Type': 'application/json' }
    });
    // Save the OnePay reference into the orders table
 // assuming reference is returned in the response
    // Save the ipg_transaction_id in the payment_reference column
    

    console.log("[Checkout] Payment reference saved in DB.");

    // Displaying the JSON response from OnePay
    console.log("\n--- ONEPAY API RESPONSE ---");
    console.log(JSON.stringify(onePayResponse.data, null, 2)); // Format the JSON output

    console.log("[Checkout] OnePay API call successful.");

    // 6. Return Redirect URL to Frontend
    console.log(`[Checkout] Sending response to frontend for ${orderReference}.`);
    return res.status(200).json(onePayResponse.data);


  } catch (e) {
    // --- CATCH BLOCK WITH VERBOSE LOGGING ---
    console.error(`\n--- !!! [Checkout Error] Ref: ${orderReference} !!! ---`); 
    
    // Log the actual error that caused the 500
    console.error("Error details:", e.message);
    console.error("Error Stack:", e.stack);

    // Log Axios-specific details if available
    if (axios.isAxiosError(e) && e.response) {
      console.error("Axios Status:", e.response.status);
      console.error("Axios Body:", JSON.stringify(e.response.data, null, 2));
    } else if (axios.isAxiosError(e) && e.request) {
        console.error("Axios Request Error: No response received (Network/Timeout issue).");
    }

    // Rollback the DB transaction if it started
    try {
      await conn.rollback();
      console.error("[Checkout Error] DB transaction rolled back.");
    } catch (rollbackError) {
      console.error("[Checkout Error] FAILED TO ROLLBACK DB TRANSACTION:", rollbackError.message);
    }
    
    // Send a JSON error response to the client
    if (!res.headersSent) { 
      return res.status(500).json({ 
        ok: false, 
        message: "server_error", 
        error: e.message || 'Unknown error occurred in checkout process.' 
      }); 
    } else {
        console.error("[Checkout Error] Headers already sent, cannot send error JSON.");
    }
    
  } finally {
    // --- FINALLY BLOCK ---
    console.log(`[Checkout] Releasing DB connection for ${orderReference}.`);
    conn.release();
    console.log(`--- [Checkout End] Ref: ${orderReference} ---\n`);
  }
});


/* ==================================================================== */
/* 2) PAYMENT WEBHOOK (NEW ENDPOINT - SERVER-TO-SERVER) */
/* ==================================================================== */
app.post("/api/payment/webhook", async (req, res) => {
  const webhookPayload = req.body;
  console.log("\n--- WEBHOOK RECEIVED ---");
  console.log(JSON.stringify(webhookPayload, null, 2));

  if (!webhookPayload || !webhookPayload.transaction_id || !webhookPayload.status) {
    console.warn("[Webhook] Received an invalid/missing format. Payload requires transaction_id and status.");
    return res.status(400).json({ status: "invalid_format", received: webhookPayload });
  }

  // --- CORRECTED PAYLOAD PARSING ---
  // Based on your confirmed format: status=1 is SUCCESS
  const reference = webhookPayload.reference || webhookPayload.transaction_id; 
  const status_code = String(webhookPayload.status); // "1" for SUCCESS
  const onepay_transaction_id = webhookPayload.transaction_id;
  const status_message = webhookPayload.status_message;
  
  // Acknowledge the webhook immediately so OnePay doesn't retry
  res.status(200).json({ status: "received", processing: true });

  // --- Start Processing ---
  const conn = await pool.getConnection();
  // CRITICAL FIX: The lookup key should be the reference sent by OnePay
  const lookupKey = String(reference || onepay_transaction_id); 
  
  try {
    await conn.beginTransaction();

    // FIND ORDER: This robust query checks if the lookupKey matches the orders.order_ref OR 
    // an existing transaction ID in the payments table for an order currently 'pending'.
    const [simpleRows] = await conn.execute(
        `SELECT * FROM orders 
         WHERE order_ref = :ref OR EXISTS (SELECT 1 FROM payments WHERE tx_id = :ref AND order_id = orders.id)
         LIMIT 1 FOR UPDATE`,
        { ref: lookupKey }
    );
    
    if (!simpleRows.length || simpleRows[0].status !== 'pending') {
        console.warn(`[Webhook] No 'pending' order found for key: ${lookupKey}. Status: ${simpleRows.length ? simpleRows[0].status : 'NOT FOUND'}. Ignoring webhook.`);
        await conn.rollback();
        return;
    }
    
    const order = simpleRows[0];
    const orderId = order.id;
    const originalOrderRef = order.order_ref; // The ref you created: ORDGMG...

    // --- PAYMENT FAILED (Status != 1) ---
    if (status_code !== "1") {
      console.log(`[Webhook] Payment FAILED for ${originalOrderRef}. Status: ${status_message}. Updating order status.`);
      await conn.execute( "UPDATE orders SET status = 'failed' WHERE id = :orderId", { orderId } );
      if (order.hold_id) {
         await conn.execute("DELETE FROM seat_locks WHERE hold_id = :holdId", { holdId: order.hold_id });
      }
      await conn.commit();
      return;
    }

    // --- PAYMENT SUCCESSFUL (Status == 1) ---
    console.log(`[Webhook] Payment SUCCESS for ${originalOrderRef}. Confirming order.`);

    // 1. Update order status to 'paid'
    await conn.execute( "UPDATE orders SET status = 'paid' WHERE id = :orderId", { orderId } );

    // 2. Insert/Update payments table
    await conn.execute(
      `INSERT INTO payments (order_id, provider, tx_id, amount, currency, status, raw_payload)
       VALUES (:orderId, 'onepay', :txId, :amount, :currency, 'captured', :raw)
       ON DUPLICATE KEY UPDATE status = 'captured', raw_payload = :raw`,
      { 
        orderId, 
        txId: onepay_transaction_id, 
        amount: Number(order.gross_amount), // Use amount saved in the DB from checkout step
        currency: order.currency, 
        raw: JSON.stringify(webhookPayload) 
      }
    );

    // 3. Get items and create tickets + permanent locks
    const [items] = await conn.execute( "SELECT * FROM order_items WHERE order_id = :orderId", { orderId } );
    const seatPairs = [];
    for (const it of items) {
      if (it.item_type === "seat" && it.table_id && it.seat_no != null) {
        seatPairs.push([String(it.table_id), Number(it.seat_no)]);
        const ticketCode = `T-${crypto.randomBytes(8).toString("hex").toUpperCase()}`;
        await conn.execute( `INSERT INTO tickets (order_id, table_id, seat_no, qr_code, status) VALUES (:orderId, :tableId, :seatNo, :qr, 'valid')`, { orderId, tableId: it.table_id, seatNo: it.seat_no, qr: ticketCode } );
        await conn.execute( `INSERT INTO done_seatlocks (event_id, order_id, table_id, seat_no) VALUES ('default', :orderId, :tableId, :seatNo) ON DUPLICATE KEY UPDATE event_id = VALUES(event_id)`, { orderId, tableId: it.table_id, seatNo: it.seat_no } );
      }
    }

    // 4. Clear temporary hold
    if (order.hold_id) {
      await conn.execute("DELETE FROM seat_locks WHERE hold_id = :holdId", { holdId: order.hold_id });
    }

    // 5. Commit transaction
    await conn.commit();
    console.log(`[Webhook] Order ${originalOrderRef} (ID: ${orderId}) fully confirmed and tickets created. Sending Email.`);

    // 6. Generate QR and Send Email (outside the transaction)
    const qrJson = buildQrJson({ orderId, orderRef: originalOrderRef, txId: onepay_transaction_id, seats: seatPairs });
    const qrPngBuffer = await QRCode.toBuffer(qrJson, { type: "png", margin: 1, width: 600 });
    
    if (mailEnabled) {
        const sentFrom = new Sender(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
        const recipients = [new Recipient(String(order.customer_email), String(order.customer_first_name || ""))];
        const pngB64 = toBase64(qrPngBuffer);
        const attachments = [new Attachment(pngB64, `ticket-${orderId}.png`, 'attachment')];
        const emailParams = new EmailParams()
            .setFrom(sentFrom).setTo(recipients)
            .setSubject(`Your Ticket • Order #${orderId}`)
            .setHtml( ticketEmailHtml({ firstName: String(order.customer_first_name || ""), orderId, orderRef: originalOrderRef, total: Number(order.gross_amount).toFixed(2), currency: order.currency }) )
            .setAttachments(attachments);
        mailerSend.email.send(emailParams).then((response) => { 
           console.log(`[MailerSend] SUCCESS: id=${response.headers["x-message-id"]} (order ${orderId})`); 
        }).catch((error) => {
           console.error(`[MailerSend] FAILED (order ${orderId}):`, error?.body || error);
        });
    }

  } catch (e) {
    await conn.rollback();
    console.error(`[Webhook] CRITICAL FAILURE processing ${lookupKey}:`, e);
  } finally {
    conn.release();
  }
});

/* ==================================================================== */
/* 3) CHECK PAYMENT STATUS (NEW ENDPOINT - FOR FRONTEND) */
/* ==================================================================== */
app.post("/api/payment/status", async (req, res) => {
  const { onepay_transaction_id } = req.body;
  if (!onepay_transaction_id) { return res.status(400).json({ ok: false, message: "onepay_transaction_id is required" }); }
  
  // New: Use the transaction ID to look up the order status in the DB
  const conn = await pool.getConnection();
  try {
      const [rows] = await conn.execute(
        `SELECT o.status, o.order_ref
         FROM orders o 
         INNER JOIN payments p ON o.id = p.order_id 
         WHERE p.tx_id = :txId 
         LIMIT 1`,
        { txId: onepay_transaction_id }
      );
      
      const orderStatus = rows.length ? rows[0].status : 'not_found';
      const orderRef = rows.length ? rows[0].order_ref : null; // Get the original reference
      
      // Respond based on the DB status
      if (orderStatus === 'paid' || orderStatus === 'checked_in') {
          // Success: Use the original reference for the frontend redirect
          return res.status(200).json({ status: 200, message: "Payment confirmed.", data: { status_code: "200", reference: orderRef } });
      } else if (orderStatus === 'failed') {
          // Failed: Explicitly tell the frontend it's failed
          return res.status(200).json({ status: 200, message: "Payment failed.", data: { status_code: "400", status_message: "Payment Failed/Declined" } });
      } else {
          // Pending/Not Found: Tell the frontend to wait or retry
          return res.status(200).json({ status: 200, message: "Status pending/unverified.", data: { status_code: "500", status_message: "Verification Pending" } });
      }
      
  } catch (error) {
    console.error("Error checking payment status via DB:", error.message);
    return res.status(500).json({ ok: false, message: "Failed to check payment status (DB error)." });
  } finally {
      conn.release();
  }
});

/* ==================================================================== */
/* 4) YOUR OTHER ENDPOINTS (UNCHANGED) */
/* ==================================================================== */

/* Support Success.jsx fallback: GET /api/orders/:ref */
app.get("/api/orders/:ref", async (req, res) => {
  const ref = String(req.params.ref || "");
  if (!ref) return res.status(400).json({ ok: false, message: "missing ref" });
  try {
    const [rows] = await pool.execute( `SELECT id, order_ref, currency, net_amount, gross_amount, status, customer_first_name, customer_last_name, customer_email, customer_phone FROM orders WHERE order_ref = :ref LIMIT 1`, { ref } );
    if (!rows.length) return res.status(404).json({ ok: false, message: "not_found" });
    const order = rows[0];
    const [items] = await pool.execute( `SELECT item_type, table_id, seat_no, qty, unit_price, amount FROM order_items WHERE order_id = :id`, { id: order.id } );
    const seatPairs = (items || []).filter((r) => r.item_type === "seat" && r.table_id && r.seat_no != null).map((r) => [String(r.table_id), Number(r.seat_no)]);
    const qrJson = buildQrJson({ orderId: order.id, orderRef: order.order_ref, txId: "", seats: seatPairs });
    const qrDataUrl = await QRCode.toDataURL(qrJson, { margin: 1, width: 480 });
    return res.status(200).json({ ok: true, order: { id: order.id, orderReference: order.order_ref, txId: "", total: Number(order.gross_amount).toFixed(2), currency: order.currency, status: String(order.status).toUpperCase(), customer: { firstName: order.customer_first_name, lastName: order.customer_last_name, email: order.customer_email, phone: order.customer_phone }, qrDataUrl, qrJson } });
  } catch (e) {
    console.error("[orders/:ref] error:", e);
    return res.status(500).json({ ok: false, message: "server_error" });
  }
});

/* OPTIONAL: QR verification for scanners */
app.post("/api/qr/verify", express.text({ type: "*/*" }), async (req, res) => {
  const qrText = (typeof req.body === "string" ? req.body : "").trim();
  const v = verifyQrJson(qrText);
  if (!v.ok) return res.status(400).json({ ok: false, reason: v.reason });
  return res.status(200).json({ ok: true, data: v.data });
});

/* Seat locks API */
app.get("/api/locks", async (_req, res) => {
  try {
    await pool.execute("DELETE FROM seat_locks WHERE expires_at < NOW()");
    const [temp] = await pool.execute( `SELECT table_id AS tableId, seat_no AS seatNo FROM seat_locks WHERE event_id='default' AND expires_at > NOW()` );
    const [paid] = await pool.execute( `SELECT table_id AS tableId, seat_no AS seatNo FROM done_seatlocks WHERE event_id='default'` );
    return res.status(200).json({ ok: true, locks: [...temp, ...paid] });
  } catch (e) {
    console.error("[locks] GET error:", e);
    return res.status(500).json({ ok: false, message: "locks_fetch_failed" });
  }
});

app.post("/api/locks/hold", async (req, res) => {
  const eventId = "default";
  const { seats = [], ttlSec = 600, holdId } = req.body || {};
  if (!Array.isArray(seats) || seats.length === 0) return res.status(422).json({ ok: false, message: "seats[] required" });
  if (!Number.isFinite(ttlSec) || ttlSec <= 0) return res.status(422).json({ ok: false, message: "ttlSec invalid" });
  const newHoldId = holdId || `H${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`.toUpperCase();
  const expiresAt = new Date(Date.now() + ttlSec * 1000);
  const pairsSql = seats.map(() => "(?, ?)").join(",");
  const pairsArgs = seats.flatMap((s) => [String(s.tableId), Number(s.seatNo)]);
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [paidRows] = await pool.execute( `SELECT table_id AS tableId, seat_no AS seatNo FROM done_seatlocks WHERE event_id=? AND (table_id, seat_no) IN (${pairsSql})`, [eventId, ...pairsArgs] );
    if (paidRows.length) { await conn.rollback(); return res.status(409).json({ ok: false, message: "Some seats already sold", conflicts: paidRows }); }
    const [tempRows] = await pool.execute( `SELECT table_id AS tableId, seat_no AS SeatNo, hold_id AS holdId FROM seat_locks WHERE event_id=? AND expires_at > NOW() AND (table_id, seat_no) IN (${pairsSql})`, [eventId, ...pairsArgs] );
    const conflicts = (tempRows || []).filter((r) => !holdId || r.holdId !== holdId);
    if (conflicts.length) { await conn.rollback(); return res.status(409).json({ ok: false, message: "Some seats already held", conflicts: conflicts.map((c) => ({ tableId: c.tableId, seatNo: c.SeatNo })) }); }
    for (const s of seats) { await conn.execute( `INSERT INTO seat_locks (event_id, table_id, seat_no, hold_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE hold_id=VALUES(hold_id), expires_at=VALUES(expires_at)`, [eventId, String(s.tableId), Number(s.seatNo), newHoldId, expiresAt] ); }
    await conn.commit();
    return res.status(200).json({ ok: true, holdId: newHoldId, seats, expiresAt: Math.floor(expiresAt.getTime() / 1000) });
  } catch (e) {
    await conn.rollback();
    console.error("[locks] POST error:", e);
    return res.status(500).json({ ok: false, message: "hold_failed" });
  } finally {
    conn.release();
  }
});

/* Dev: test deliverability */
app.get("/api/dev/test-mail", async (req, res) => {
  if (!mailEnabled) return res.status(503).json({ ok: false, message: "mail_disabled (check env)" });
  const to = String(req.query.to || "").trim();
  if (!to) return res.status(400).json({ ok: false, message: "missing 'to' query param" });
  try {
    const sentFrom = new Sender(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
    const recipients = [new Recipient(to)];
    const emailParams = new EmailParams().setFrom(sentFrom).setTo(recipients).setSubject("Eventz test mail (MailerSend)").setText("If you can read this, MailerSend API is working.");
    const response = await mailerSend.email.send(emailParams);
    return res.json({ ok: true, messageId: response.headers["x-message-id"], response: response.body });
  } catch (e) {
    console.error("[dev/test-mail] MailerSend error:", e?.body || e);
    return res.status(500).json({ ok: false, message: e?.body?.message || "send_failed", details: e?.body?.errors });
  }
});

/* ───────── START ───────── */
app.listen(Number(PORT), () => {
  console.log(`[API] listening on http://localhost:${PORT} (origin: ${FRONTEND_ORIGIN})`);
});
